package com.RISDATA.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.RISDATA.dao.BaseDao;
import com.RISDATA.dao.SampleDataDao;
import com.RISDATA.entity.SampleData;

public class SampleDataDaoImpl implements SampleDataDao {

	@Override
	public void del(int id) {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = BaseDao.getConn();
			String sql = "delete from BI_YJ where _id=?";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, id);
			ps.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			BaseDao.closeAll(conn, ps, null);
		}

	}

	@Override
	public void save(SampleData data) {
		Connection conn = null;
		PreparedStatement ps = null;
		try {

			conn = BaseDao.getConn();
			String sql = "insert into  BI_YJ (mdbh,spxh,cysl,cyrq,pldm) values(?,?,1,?,?)";
			ps = conn.prepareStatement(sql);
			ps.setString(1, data.getStoreNum());
			ps.setString(2, data.getSize());
			ps.setString(3, data.getTime());
			ps.setString(4, data.getStyleNum());
			ps.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			BaseDao.closeAll(conn, ps, null);
		}

	}

	@Override
	public List<SampleData> findAll() {
		List<SampleData> list = new ArrayList<SampleData>();
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			conn = BaseDao.getConn();
			String sql = "select mdbh,spxh,cyrq,pldm from bi_yj";
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				String store = rs.getString("mdbh");
				String size = rs.getString("spxh");
				String date = rs.getString("cyrq");
				String style = rs.getString("pldm");
				SampleData sampleData = new SampleData(store, size, date, style);
				list.add(sampleData);
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			BaseDao.closeAll(conn, ps, rs);
		}
		return list;

	}

	@Override
	public void update(int id) {
		// TODO Auto-generated method stub

	}

}
