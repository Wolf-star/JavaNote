package com.RISDATA.entity;

public class SampleData {
	private String storeNum;
	private String size;
	private String time;
	private String styleNum;


	public String getStoreNum() {
		return storeNum;
	}

	public void setStoreNum(String storeNum) {
		this.storeNum = storeNum;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getStyleNum() {
		return styleNum;
	}

	public void setStyleNum(String styleNum) {
		this.styleNum = styleNum;
	}

	public SampleData() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SampleData(String storeNum, String size, String time, String styleNum) {
		super();
		this.storeNum = storeNum;
		this.size = size;
		this.time = time;
		this.styleNum = styleNum;
	}

}
