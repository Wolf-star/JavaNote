package com.RISDATA.test;

import java.util.List;
import java.util.Scanner;

import com.RISDATA.dao.SampleDataDao;
import com.RISDATA.dao.impl.SampleDataDaoImpl;
import com.RISDATA.entity.SampleData;

public class Test {

	public static void main(String[] args) {
		// ɾ��
		Scanner in = new Scanner(System.in);
		/*
		 * System.out.println("pls input the num your want to delete:"); int
		 * id=in.nextInt();
		 */
		SampleDataDao sample = new SampleDataDaoImpl();

		// sample.del(id);
		
		
		// ����
		// SampleData sample=new SampleData();
		/*
		 * System.out.println("pls input your store NO.:"); String store = in.next();
		 * System.out.println("pls input your sample size:"); String size = in.next();
		 * System.out.println("pls input your sample style:"); String style = in.next();
		 * Date date = new Date(); SimpleDateFormat sdf = new
		 * SimpleDateFormat("yyyy-MM-dd"); String d = sdf.format(date); SampleData
		 * sampleData = new SampleData(store, size, d, style);
		 * 
		 * sample.save(sampleData);
		 */
		
		//��ѯ
		List<SampleData> samples =sample.findAll();
		for(SampleData sd:samples) {
			//samples s=samples.get(sd);
			System.out.println(sd.getStoreNum()+"\t"+sd.getSize()+"\t"+sd.getTime()+"\t"+sd.getStyleNum());
		}

	}

}
